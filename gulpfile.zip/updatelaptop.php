<?php 
// koneksi database
include 'koneksi.php';
 
// menangkap data yang di kirim dari form
$id = $_POST['id'];
$serial_number = $_POST['serial_number'];
$merk = $_POST['merk'];
$type = $_POST['type'];
$status = $_POST['status'];
$lokasi = $_POST['lokasi'];


// update data ke database
mysqli_query($conn,"update data_laptop set serial_number='$serial_number', merk='$merk', type='$type', status='$status', lokasi='$lokasi' where id='$id'");
 
// mengalihkan halaman kembali ke index.php
header("location:Dlaptop.php");
 
?>